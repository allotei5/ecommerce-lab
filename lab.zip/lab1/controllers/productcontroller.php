<?php
//connect to the product class
require("../classes/productclass.php");

//add new brand function
//takes brand name

function addNewBrand($brandName){
    //create an instance
    $newProductObject = new productClass();
    
    //run the add new brand method
    $addBrand = $newProductObject->addNewBrand($brandName);
    
    if ($addBrand){
        //return the query result
        return $addBrand;
    }else{
        return false;
    }
}

/*
display all brands
*/
function returnBrands(){
    //create an instance
    $newProductObject = new productClass();
    
    //run the select all brands method
    $selectBrands = $newProductObject->displayBrands();
    
    //check if select worked
    if ($selectBrands){
        
        $brands = array();
        
        while($record = $newProductObject->db_fetch()){
            $brands[$record['brand_id']] = $record['brand_name'];
        }
        
        //return the array
        return $brands;
        
    }else{
        return false;
    }
    
}

function returnBrandNames(){
    //create an instance
    $newProductObject = new productClass();
    
    //run the select all brands method
    $selectBrands = $newProductObject->displayBrands();
    
    //check if select worked
    if ($selectBrands){
        
        $brandNames = array();
        
        while($record = $newProductObject->db_fetch()){
            array_push($brandNames, $record['brand_name']);
        }
        
        //return the array
        return $brandNames;
        
    }else{
        return false;
    }
}

//update brand name
function updateBrandName($brandID, $brandName){
    //create an instance
    $newProductObject = new productClass();
    
    //run the update method
    $updateBrand = $newProductObject->updateBrand($brandID, $brandName);
    
    //check if it worked
    if($updateBrand){
        return $updateBrand;
    }else{
        return false;
    }
}

//delete brand name
function deleteBrandName($brandID){
    //create an instance
    $newProductObject = new productClass();
    
    //run the update method
    $deleteBrand = $newProductObject->deleteBrand($brandID);
    
    //check if it worked
    if ($deleteBrand){
        return $deleteBrand;
    }else{
        return false;
    }
}

//add a new category
function addCategory($name){
    //create an instance of the class
    $newProductObject = new productClass();
    
    //run the add category method
    $addCategory = $newProductObject->addCategory($name);
    
    //check if it worked
    if($addCategory){
        return $addCategory;
    }else{
        return false;
    }
}

//view all categories
function displayCategories(){
    //create an instance of the class
    $newProductObject = new productClass();
    
    //run the display categories method
    $displayCategory = $newProductObject->displayCategories();
    
    //check if it worked
    if ($displayCategory){
        
        $categories = array();
        
        //loop through the rows
        while($record = $newProductObject->db_fetch()){
            $categories[$record['cat_id']] = $record['cat_name'];
        }
      
        //return array
        return $categories;
    }else{
        return false;
    }
}

//update a category
function updateCategory($id, $name){
    //create an instance of the class
    $newProductObject = new productClass();
    
    //run the display categories method
    $updateCategory = $newProductObject->updateCategory($id, $name);
    
    //check if it worked
    if($updateCategory){
        return $updateCategory;
    }else{
        return false;
    }
}

//delete a category
function deleteCategory($id){
    //create an instance of the class
    $newProductObject = new productClass();
    
    //run the display categories method
    $deleteCategory = $newProductObject->deleteCategory($id);
    
    //check if it worked
    if($deleteCategory){
        return $deleteCategory;
    }else{
        return false;
    }
}
?>