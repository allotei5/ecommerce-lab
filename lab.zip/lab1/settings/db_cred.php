<?php
//Database credentials
define("DATABASE", "shoppn");
define("SERVER", "localhost");
define("USERNAME", "root");
define("PASSWD", "");

?>