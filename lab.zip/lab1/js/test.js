document.getElementById("add").onclick = function(){
    alert("connected")
}